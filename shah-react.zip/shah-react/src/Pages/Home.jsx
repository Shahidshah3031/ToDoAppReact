import React from 'react'
import TodoComponent from "../Components/TodoComponent"
import 'bootstrap/dist/css/bootstrap.min.css';
export default function Home() {
  return (
    <div>
        <TodoComponent />
    </div>
  )
}